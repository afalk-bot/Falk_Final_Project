"""
Game that simulates a student's 
day in the life at Holy Cross, 
given user input to determine 
the student's accomplishments and 
productivity level of the day
"""

import random

def on_time_wakeup():
    """
    Determines if user wakes up on time for 8am class 
    and other morning accomplishments. 

    Inputs: mins_before_class: Number of minutes user
    wakes up before 8am.

    Output: Message about how morning went and 
    number of points gained or lost. 
    """
    points=0 

    mins_before_class=float(input(
        "How many minutes before 8am did you wake up?"))

    while mins_before_class<0:
        print("Invalid input! Can't have negative minutes!")
        mins_before_class=float(input(
            "How many minutes did you wake up before 8am?"))

    if mins_before_class>=60:
        points=10
        result= ("Great start to the day!\n"
        "You have time to study, get a coffee,\n" 
        "and make it to class on time!")
    elif mins_before_class<60 and mins_before_class>30:
        points=5
        result=("Good start to the day!\n" 
        "You have time to get a coffee\n"
        "and you get to class on time")
    elif mins_before_class<=30 and mins_before_class>20:
        points=3
        result=("You wake up to make class on time,\n"
        "but no time for coffee!")
    elif mins_before_class<=20 and mins_before_class>5:
        points=-3
        result=("You're late to class :(")
    else:
        points=-10
        result=("You missed your 8am.")
    
    print(result)
    print(F"You earned {points} productivity points")

    return points


def nine_am_ontime():
    """
    Determines if user makes it on time to 9 am
    based on how many minutes before they leave, 
    and if campus is crowded. 

    Inputs: 
    leave_for_nine_am: How many mins before 9am did user leave their 8am 
    or dorm if they missed class.  

    Outputs: Whether or not they are ontime, late, or don't make 
    it to class, and the points they gained or lost.
    """
    points=0

    leave_for_nine_am=float(input(
        "How many minutes before 9am did you leave for class?"
    ))

    while leave_for_nine_am<0:
        print("Invalid input! No negative minutes!")
        leave_for_nine_am=float(input("How many minutes before 9am did you leave for class?"))

    random_num=random.random()
    is_crowded=random_num>0.5

    if leave_for_nine_am>=5:
        points=3
        result=("You make it to you 9am on time!")
    if leave_for_nine_am<5 and leave_for_nine_am>=1:
        if is_crowded:
            points=-3
            result=("Late for 9am")
        else:
            points=2
            result=("On time for class")
    if leave_for_nine_am<1:
        points=-10
        result=("You missed your 9am")
    
    print(result)
    print(f"You earned {points} productivity points")

    return points


def between_ten_and_eleven():
    """
    Determines number of productivity points gained in 
    hour between Python class and Calc class based on if the
    user ate breakfast or not, how many assignments 
    they completed, and if they studied or not. 
    
    Inputs: 
    Yes or no for having eaten breakfast
    Integer for number of homework assignments completed
    Yes or no for studying

    Outputs: A statement about what they did and how many 
    points they gained or lost from it. 
    """

    points=0

    eat_breakfast=input("Did you eat breakfast?").lower()

    while eat_breakfast not in ["yes","no"]:
        print("Invalid input! Answer with yes or no.")
        eat_breakfast=input("Did you eat breakfast?").lower()
    
    eat_breakfast=eat_breakfast=="yes"
   
    assignments_done=int(input(
        "How many assignments did you finish?"
    ))

    while assignments_done<0:
        print("Invalid Input.")
        assignments_done=int(input(
        "How many assignments did you finish?"
    ))
    
    study=input("Did you study (yes/no)?").lower()

    while study not in ["yes","no"]:
        print("Invalid input! Answer with yes or no.")
        study=input("Did you study (yes/no)?").lower()

    study=study=="yes"

    if not eat_breakfast and assignments_done<1 and not study:
        points=-10
        result=("You were not productive.")
    elif eat_breakfast and study and assignments_done>=1:
        points=10
        result=("Great job, you were very productive!")
    elif (
        (eat_breakfast and not study and assignments_done<1) or 
        (not eat_breakfast and study and assignments_done<1) or
        (not eat_breakfast and not study and assignments_done>=1)):
        points=3
        result=("You did something productive")
    else:
        points=5
        result=("You were productive!")
    
    print(result)
    print(f"You earned {points} productivity points")

    return points
    
     

def calc_participation():
    """
    Rewards productivity points based on how many times 
    user participates in 11am calc class

    Input: Ask user for an integer of number of times they 
    participates in class (asks/answers a question)

    Output: Statement of number of time participated and the points
    gained or lost.
    """
    points=0

    participate_count=int(input(
        "How many times did you participate?"))
    
    while participate_count<0:
        print("Invalid input!")
        participate_count=int(input(
        "How many times did you participate?"))

    if participate_count<1:
        points=-5
        result=("You didn't participate in class")
    elif participate_count==1:
        points=1
        result=("You participated once. Nice!")
    elif participate_count ==2:
        points=2
        result=("Good participation!")
    else:
        points=3
        result="That was a super productive Calc class!"

    print(result)
    print(f"You earned {points} productivity points")
    
    return points


def twelve_to_three():
    """
    Allow user to choose how to spend their afternoon
    and calculate productivity based on decisions.
    """

    afternoon_activities={
        "Study":5,
        "Starbucks trip":1,
        "Attend office hours":7,
        "Take a Nap":2,
        "Pick up packages and clean room":3,
        "Complete Homework": 6,
        "Watch Tv":0,
        "Get lunch":4
    }

    hours=[1,2,3]
    completed_activities=[]
    points=0

    print("It's noon and you have 3 hours until your next scheduled event.\n"
    "How will you spend this time?")

    for hour in hours:
        print("Available Activities:")
        for option in afternoon_activities:
            print(option)

        activity=input(f"What activity will you do during hour {hour}?")

        while activity not in afternoon_activities:
            print("Invalid activity!")
            activity=input(f"What activity will you do during hour {hour}?")

        completed_activities.append(activity)
        points+=afternoon_activities[activity]

        print(f"During hour {hour}, you chose to {activity}.\n"
                  f"You get {afternoon_activities[activity]} points!")
        
           
    print("Activities completed:",completed_activities)
    print(f"You earned {points} productivity points")

    if points>=8:
        print("You had a productive afternoon!")
    else:
        print("You could have been more productive.")
        
    return points

    
def office_hours():
    """
    Simulates whether or not students show up for help,
    and if they don't, how many assignments you get to grade. 
    """
    print("Now it's time for your office hours from 3-5")

    students_come=random.random()<0.4

    if students_come:
        points=10
        print("Students attended office hours so you helped them. Very productive!")
    else:
        print("No students showed up. Time to grade assignments!")

        number_assignments=int(input("How many papers do you have to grade this week?"))
       
        while number_assignments<=0:
            print("Invalid number of assignments!")
            number_assignments=int(input("How many papers do you have to grade this week?"))

        assignments_graded=random.randint(0,number_assignments)
        print(f"You graded {assignments_graded} during office hours.")

        if assignments_graded==number_assignments:
            points=10
            print("Awesome job, you finished all grading!")
        elif assignments_graded>=number_assignments/2:
            points=5
            print("Good work, you graded half of the homeworks")
        elif assignments_graded>number_assignments/4:
            points=3
            print("Nice, you got some grading done")
        elif assignments_graded>0:
            points=1
            print("You made some progress grading")
        else:
            points=-10
            print("You could have been more productive during this time.")
        
    print(f"You earned {points} productivity points")
    
    return points
 

def dinner():

    print("Now it's dinner time! Here are your options:")
    
    dinner_options={
        "Kimball":0,
        "Croads":10,
        "Pick up fast food":15,
        "Doordash":30,
        "Sitdown Restaurant":50
    }

    money=float(input("How much money do you have to spend on food?"))
    while money<0:
        print("Invalid input!")
        money=float(input("How much money do you have to spend on food?"))
    
    affordable=[]
    for option in dinner_options:
        if dinner_options[option]<=money:
            affordable.append(option)
    print(f"You can afford these dinner options: {affordable}")

    dinner_choice=input("What will you do for dinner?")
    while dinner_choice not in affordable:
        print("Invalid choice!")
        dinner_choice=input("What will you do for dinner?")

    if dinner_choice=="Kimball":
        points=10
    elif dinner_choice=="Croads":
        points=8
    elif dinner_choice=="Pick up fast food":
        points=5
    elif dinner_choice=="Doordash":
        points=3
    elif dinner_choice=="Sitdown Restaurant":
        points=1
    
    cost=dinner_options[dinner_choice]
    money=money-cost

    print(f"You chose the dinner option:{dinner_choice}\n"
          f"You have {money} dollars remaining.\n"
          f"You earned {points} points based on how much you spent.\n")
    
    return points

    
def bedtime():

    print("That was a long day, time for bed!")
    points=0

    phone_time=float(input("How much time did you spend scrolling before bed?"))

    while phone_time<0:
        print("Invalid input!")
        phone_time=float(input("How much time did you spend scrolling before bed?"))
    
    if phone_time==0:
        points=15
    elif phone_time<15:
        points=10
    elif phone_time<30:
        points=5
    elif phone_time<45:
        points=3
    else:
        points=0
    
    print(f"You spent {phone_time} minutes scrolling.\n"
          f"You get {points} points")
    
    return points
        

def main():
    """
    Puts all Holy Cross Day in the life functions 
    together to find the overall productivity of the day
    and determine if the user won or lost. 
    """

    print("Welcome to a Day in the Life at Holy Cross!\n"
          "Make decisions about your day and see how\n"
          "productive you were!")
          
    total_points=sum(
        [on_time_wakeup(),
         nine_am_ontime(),
         between_ten_and_eleven(),
         calc_participation(),
         twelve_to_three(),
         office_hours(),
         dinner(),
         bedtime()]
         )
    
    print(f"Your total score is {total_points}!")

    if total_points>=60:
        print("You win! You had a great day and got a lot done!")
    elif total_points>=45:
        print("You win! You had a solid day.")
    else:
        print("You lost! Try to be more productive tomorrow!")

if __name__=="__main__":
    main()
















